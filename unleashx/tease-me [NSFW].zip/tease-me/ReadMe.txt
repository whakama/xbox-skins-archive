
==========================
====JALOVERBOY AKA RTD====
==========================
email: jaloverboy@gmail.com

Guys love cars and guys love chicks, perfect combination.


I created this skin using Adobe ImageStyler and Photo Shop.

You can email me your comments. 


Quote: You like the car if you are blind, the girl looks better.
