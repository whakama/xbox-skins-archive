Hi all,this is the fixed and final version of the Evolution skins i put together
for unleashX,i cant take full cred as i got the background pic frm an MxM
skin called Fusion V2.0 by Habs69M,so all cred goz to him/her for the originals,
i just touched em up a little and had a little help frm tweaqr(thanks mister)just 
pop the Evolution Final.zip(yes UnleashX supports zip)in a folder in the skins folder 
on c:\Skins and happy dayz =0) (e.g.C:\Skins\Evolution Final\place zip here)


-Fixed menu to show correctly(not like Gam... now shows full names,Games).
-Moved time and date etc.
-Removed Nick.
-Removed the songtime,title.
-Added Menu font(Space_Age_14.xpr).
-Added Game Preview and game video support(u will need to put preview.wmv or preview.xmv.
in ur games folders,u can use UnleashX's built in filemanager to search ur games 
for the xmv/wmv file or u can get them from http://gametrailers.com/,simply open 
a game folder and copy in the file in the same folder as the default.xbe and happy dayz ). 
-Added Loading video support + loading.xmv video. 
-Added Fog support(disable or enable  Fog="False" or Fog="True")set as False atm.
-Added support for newsfeeds and confirmed workin by my self(c screenshots).
-Added suport for news source.
-Added overlay circle top left for game shot.
-Added Filemanager skin and preview shot for the menu(u will need to edit ur config.xml 
for the preview(FMBG2.jpg)image to show in ur main menu when u highlight the filemanager).
add this where u have ur filemanager section in ur config.xml,

<Item Action="FileManager" Password=" Icon="C:\Skins\Evolution Final\FMBG2.jpg">File Manager</Item>

but the above will only work if u dont install the skin as a zip,if u have it as a 
zip it wont show and u will have to put it in a seperate folder and point it to there
e.g: 
<Item Action="FileManager" Password=" Icon="E:\Icons\Evolution Final\FMBG2.jpg">File Manager</Item>

and drop the jpg in the Icons folder,
hope ya all enjoy and hope to c many more to come,


                 I Live To Give =0)
                  

P.S.I notice a couple game names r to long for the box,u can edit the xbe
with UnleashX's built in File Manager(highlight the default.xbe and push UP
on the D-Pad to get the extra options)or get XBE_Renamer0.8 frm xbins and 
rename the xbe so it fits then upload it back to the xbox.

AzA.