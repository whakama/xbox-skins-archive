Skin Name - Xbox Media Experience
By - Wabid Woveren
Platform - UnleashX


-----About-----
This skin was inspired by the Dell Media Experience.  It is part of a suite for almost every skinnable xbox application.  


-----OPTIONS------
There are two xml files included, to support the G drive.  Default is F and G.  To change to  E and F rename Skin.xml to FGSkin.xml and EFSkin.xml to Skin.xml.  There are also two more versions of EF/FG that support preview videos, so there are a total of four skin.xml files to choose from.  Choose Wisely, just like Indy.


-----Thanx------
A big thank you goes out to Shadow_MX for helping with these skins and for creating his share of the suite.  Also thank you to Dell for making a great looking program that is easy to rip apart.  A special thanks goes out to Dunny for Console U.I., yourwishismine, for his Console U.I. Green Preview Video mod, and dragonforce99 for Media Center Unleashed.  Their skins were used to learn the UnleashX skin language, and as WIP templates.  And finally to Unleash-X for creating UnleashX.

-----Use------
Feel free to create whatever skin you want, however I ask that you please give me credit in your readme.  A name is sufficient.