
==========================
====JALOVERBOY AKA RTD====
==========================
email: jaloverboy@gmail.com

This skin was inspired by the Unleash Kiss skin.

(yes that one with the two girls kissing and wearing head phones.

I created this skin using Adobe ImageStyler and Photo Shop.

This is my first attempt at making skins, have fun.

You can email me your comments. 


PS: I can't take credit for the pictures with the girls, I got it from a Evox skin (I think).
