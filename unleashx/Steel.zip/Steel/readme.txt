Information
-----------
-"Steel" by JhunKOF2k
  Version 1.2938726495 (really!)
  All Original Materials Copyright 2004
-Since the focus of this skin is the over-sized preview
  video, the preview audio is turned on.  I recommend
  encoding all your preview movies in the highest 
  quality setting possible.
-"Steel" is a skin for Unleash X.  For more details about
  Unleash X, including the usage of this skin, please go
  to www.xbox-scene.com or www.unleashx.com

Credits
-------
-The images for "Steel" were all created with original
  material, except the XBox logo and controller,
  which were taken from a forum.  
-I used Micrografx PhotoMagic (an old but
  reliable imager), and MS Paint for the images.
-UX Sketchy Skinner was used for the initial skin.xml
  file that was later drastically altered.
-ReleashED (doesn't saying that sound like you have a
  lisp?) was used for the color scheme.
-The font, Xbox_Book_11.xpr was taken from the skin
  "Snapshots" by Hectobleezy.
-The loading and intro movies were created first by hand,
  frame-by-frame, then compiled to an .avi with 
  JPG2AVI, then encoded to .wmv with Windows Movie Maker.

Contact
-------
-Feel free to contact me at jaeaye@hotmail.com.  I accept
  all compliments, and most criticisms ^_^.  
