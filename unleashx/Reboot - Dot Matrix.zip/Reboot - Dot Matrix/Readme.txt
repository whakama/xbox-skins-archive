First off, Id like to thank you for downloading this skin.

ok, its simple, unzip the zip file, and FTP the Folder to your skins directory on the Xbox

These skins were built on an Xbox 1.6b connected to a TV tuner Card, so, you cant see part of the
menu, its because that portion of the screen is not shown on your TV. The only skin i think will have this
problem is the Teyla Emmagan Skin, since the menu is at the bottom right corner. Other than that, no
other problems persist.

If you Run In HD (ie. 1080i or Whatever) the skin wont distort, as the base images are 1024x768, small
Screens just scale them down, however, if the Scaling distorts the image, change the settings in the Skin.XML
file to render the image in the Resolution you are set at (to find out, goto UnleashX main menu, hit the Y button
and scroll down to Screen Buffer, and you should see you resolution. REMEMBER! its Width x Height, so in the
skin.XML for 800x600 it would be:

        <Image Top="0" Left="0" Width="800" Height="600" Opacity="100">bg.png</Image>

Anything above 1024x768, distorts the image, but thats only if you are on a Computer Monitor.
 

Disclaimer: I am not responsible for screw ups that happen to your xbox, thats when you complain
to microsoft, give them a call, or just ask people up at Xbox-scene, im sure UnleashX hangs around
there somewhere. 

The Basis of these Skins, are built from pieces of other skins, some more than others. C

Credits:

Xenosaga Skin: Kracker
Animetrix skin: (whoever created it....)
The basis of the Dot matrix skin, well, that was used alot and i forget the actual name of the skin, but thanks :)

The SRIX Toolkit:

THe program I used to build some of these skins were built in a small editor that i recently built
in visual basic studio, and i wont be releasing the tool, because it has some bugs in it, and
its nothing but a text editor with some find and replace scripts. 

ok, thats pretty much it.

Questions?
Contact me @  Tannermckenney270@hotmail.com 
 if i dont get back to you for a while, its because some mail ends up in the junk bin. 

Sajuuk
Storm Raider Industries (SRI) �