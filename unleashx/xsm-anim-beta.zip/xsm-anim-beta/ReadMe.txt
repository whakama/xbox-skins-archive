Hi guys , 
i just work all night to make that skin , loll
its almost done (excep: i may wan to re render the load(to be faster) ect some litle thing)

ok , the "skin.xml" is set like if you have your unleash skin folder there

C:\UnleashX\Skins\

so if your unleash folder is some where else , edit the "skin.xml"

Code:
 
<Skin name="xsm-anim-beta">
 <Information>
  <Author>Lepetitprince</Author>
  <Copyright>Copyright Lpp 2004</Copyright>
  <Version>Beta</Version>
 </Information>
  <IntroMovie 
Enableaudio="False">C:\UnleashX\Skins\xsm-anim-beta\Intro.xmv
</IntroMovie> 
...
Code:
 edit where the intro vid is 
(ex: my is: E:\logiciels\UnleashX_0_31_0229A\Skins\xsm-anim-beta\Intro.xmv  ,loll 
hope you get it right , my english is not perfect , and im very tired,loll

Get it here

so gime your comment on this one 
(btw ist a remake of the "XMS" skin i have done for evox,but animated + intro + load(also animated))

//-----------------
Skin made by Lepetitprince
:)
