=========================
--------
Skin: C-UnleashX
Author: C-Perception
Copyright: 2004 Benjamin Lupton
Version: v1.0
--------
=========================
--------
Future:
*Different Layouts
*Gold layout, based on 'Opulance' WindowBlinds skin
*Icon Pack, based on the 'Crystal' icon packs
*Intro and Load out movies
--
You:
If you got some skills, i could do with a intro and outro movies
like the ones from 'MilyXMenu'. That would be awesome.
--
Contact:
cperception@hotmail.com
--------
=========================