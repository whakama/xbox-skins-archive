1st and last respect to KenCiro for original artwork :)


To make use of this skins extra visual features Simply add the following line to your menu items in config.xml ...

Preview="c:\skins\kyrus_mod\default.wmv" Icon="c:\skins\kyrus_mod\icon.png"



eg ...

	<List Text="Games" Sort="On" Auto="On">


becomes ...

	<List Text="Games" Sort="On" Auto="On" Preview="c:\skins\kyrus_mod\default.wmv" Icon="c:\skins\kyrus_mod\icon.png">




etc etc etc - see 'Example_Config.xml'


enjoy

A1patriot