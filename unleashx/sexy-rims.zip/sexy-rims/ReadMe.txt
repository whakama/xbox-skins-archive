
==========================
====JALOVERBOY AKA RTD====
==========================
email: jaloverboy@gmail.com

Guys love cars and guys love chick, perfect combination.


I created this skin using Adobe ImageStyler and Photo Shop.

You can email me your comments. 


Quote: Those are 18" rims sittng on some 35 series tyres. (tight)
