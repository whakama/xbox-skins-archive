
Blackbolt Console v4 for UnleashX by Kyro


I've just unleashed one of the most famous EvolutionX skin ever (Blackbolt Console v4) ;).

So credits goes to Blackbolt and also to Athloni for his UnleashX skin work.

- - -
- - - 

History :

Initial version 12/2004 :

- modify free space to suit your needs, change the object coordinates if it's not well aligned on your setup, see Skin.xml...


- - -
Kyro
