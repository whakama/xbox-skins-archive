
==========================
====JALOVERBOY AKA RTD====
==========================
email: jaloverboy@gmail.com

You can't have both, girl or car, make your pick..


I created this skin using Adobe ImageStyler and Photo Shop.

You can email me your comments. 


Quote: Keep your have off the car, ok?
