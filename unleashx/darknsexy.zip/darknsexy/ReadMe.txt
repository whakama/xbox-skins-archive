
==========================
====JALOVERBOY AKA RTD====
==========================
email: jaloverboy@gmail.com

I wanted to try the 3D effect; I think it needs work, don't you agree?


I created this skin using Adobe ImageStyler and Photo Shop, just wish I was a graphic pro.

You can email me your comments. 


Quote: Anything can be hacked, you just need time.
