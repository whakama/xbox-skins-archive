Name: IceBlue
Author: Maggy (me :D)
email: alex.fearnley@ntlworld.com
Date: 06/01/04

Notes: Its Based on the Logo for Pheonix Bios flasher for some good pics, 
and (MS for ompact)

If u wanna use any of my code feel free, but i'd like a mention in your txt some where ^_^.



***************************************************
Word up2 L33 for persuading me to m0dd0r1s3 my zbox
***************************************************


FILES:

skin.xml
fileback.jpg
bg.jpg
loading.jpg
Readme.txt
impact14.xpr
impact20.xpr