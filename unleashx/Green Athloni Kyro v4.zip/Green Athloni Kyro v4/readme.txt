History :

Version 4 :
final version, i think i improved the skin to the point i wanted to, 
so i now pass the relay ;) to anyone who wants to improve this skins his own way...

-	menu font changed to look more like the one in the original dash

-	another gfx change to show free space of 2 drives (c & e, but can be change by editing the Skin.xml)

-	temperatures & free space colons are more or less well aligned with a righ & left alignment


Version 3 :

-	based on the awesome work of Athloni on his "Green Athloni v2" skin
	(have a look at his other skins), thanks for your work

- 	gfx change to show the Xbox IP 
	(IP aligned in the middle of the gfx long enough to show the longest static or dhcp IPv4 possible)

-	minor changes to the coordinates of time, cpu & mb temp for a better alignment with the gfx

- 	change the alignment of the tray status
	(displayed outside the gfx when status was changing)

-	removed the blue background when screen was not calibrated


- - -
Kyro
30/08/2004
