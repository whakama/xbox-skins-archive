Based on Alienated 2 by ravage73 for the MXM dash
ported to unleashX by KAP

I tried to contact ravage73 to let him know that i ported this teriffic skin and to let him view it but his email no longer works. I have decided to release it on UnleashX without his knowing. If anyone can get in touch with him please tell him about it.


v2.0 update

- changed background animation
- went back to old X logo
- menu background no longer transparent



V1.5 update

- moved game icon
- added game preview (without sound, if you would like sound you must edit the skin.xml file)
- changed color scheme

:) enjoy