- Moe's skin -
-----------------
Name: Chef skin
Made for UnleashX.
Used UnleashX v0.36.0620A on a v1.1 XBox in PAL, normal (Width=640*height=576) to make this skin.
Enjoy!

Made by Moe 2005