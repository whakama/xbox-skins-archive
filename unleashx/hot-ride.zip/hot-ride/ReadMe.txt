
==========================
====JALOVERBOY AKA RTD====
==========================
email: jaloverboy@gmail.com

She is a friend of mine, give her a call..


I created this skin using Adobe ImageStyler and Photo Shop.

You can email me your comments. 

Quote: here number is 1-954-hot-ride

