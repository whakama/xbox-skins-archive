rename the desired background file to: bg.png and copy to the skin folder.

rename the desired loading file to: loading.png and copy to the skin folder.
