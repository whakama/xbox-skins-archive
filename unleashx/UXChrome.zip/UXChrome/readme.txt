Skin Name
===============================
UX Chrome

Graphic base on
===============================
Self design using Flash and Photoshop
===============================

Info
===============================
Skin: UX Chrome
Video: MXM-Starfield by koldfuzion
Author: faster90
Copyright: 2003
Version: v1.4
http://faster90.my-forums.net
===============================

Tools
===============================
Adobe Photoshop CS

Date
===============================
June 1, 2005
by, faster90

I hope you enjoy my skin.
