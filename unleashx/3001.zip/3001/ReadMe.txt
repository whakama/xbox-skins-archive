I wasnt too keen on the Background design so I seperated it from the rest of the picture making it easy to change, just alter bg.png to suite your taste ;)

Icon Style graphic was found in the fantastic Digitech Evox skin by Masamune, hope you dont mind me using it ;)

- dunny