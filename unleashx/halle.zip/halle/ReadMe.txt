
==========================
====JALOVERBOY AKA RTD====
==========================
email: jaloverboy@gmail.com

Guys, everyone loves Halle, am sure you will like this skin


I created this skin using Adobe ImageStyler and Photo Shop.

You can email me your comments. 


Quote: Sexy skin equals happy time with Xbox
