Xmetallica 0.2   

All credit goes to kruedog&driggs for creating a skin after the best band of all time ( I just modified it :)  


Added: scrolling menu items
Added: Cool xbox 360 boot video
Added: Display of song title and time
Added: Loading and filemanager background
Changed:Background picture
Changed:Time and Date moved to bottom right and IP info moved to bottom left
Changed:Game Icon 70% Opacity





Enjoy!!!!! KoRnSTAR56