Auteur: Vincent Bouchard
