First of all, credit goes to Athloni & Blackbolt for this skin. I've modified it to suit my needs and yours hopefully ;).

History :

Version 5 (maybe final, but who knows ;) ... ) :

-	Took some ideas from the famous and great skinner Blackbolt (ip has been enhanced, new wires)

Version 4 (final, i think) :

-	menu font changed to look more like the one in the original dash

-	another gfx change to show free space of 2 drives (c & e, but can be change by editing the Skin.xml)

-	temperatures & free space colons are more or less well aligned with a righ & left alignment

Version 3 :

-	based on the awesome work of Athloni on his "Green Athloni v2" skin

- 	gfx change to show the Xbox IP 
	(IP aligned in the middle of the gfx long enough to show the longest ip possible static or dhcp)

-	minor changes to the coordinates of time, cpu & mb temp for a better alignment with the gfx

- 	change the alignment of the tray status
	(displayed outside the gfx when status was changing)

-	removed the blue background when screen was not calibrated


- - -
Kyro
