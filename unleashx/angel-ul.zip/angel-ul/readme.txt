Angel-ul skin based on Brazooca skin by Marcelo242.
I really have no idea who the angel image belongs to.