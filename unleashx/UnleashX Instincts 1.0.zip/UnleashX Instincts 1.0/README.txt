--Unleash X Instincts 1.0--
October 10, 2005 by �Tattoo�
----------------------------

To install, simply copy the "Unleash X Instincts 1.0" folder in your UX skins folder!

Also due to the size of the video background I do not recommend the use of a video screensaver with this skin cause you will experience some lag.

The background, loading and Intro video contained in this skin was in part, edited from Far Cry Instincts Menu video. All other design/graphics are from me!

Music sample:
-------------
Guns and Roses - Welcome to the Jungle

Thank you for downloading my skin!

Enjoy!

�Tattoo�