Big Freeze V1.0a
--------------------------------------
This is a update to my first skin. Alot has been improved (menus, looks
etc...) Enjoy my new improved BigFreeze skin!

Again all credz goes to Blackbolt (if im not mistaken) for this background
And the author of the UX skin on the UX site.

-TaNK

email - razorkid_2000@yahoo.com