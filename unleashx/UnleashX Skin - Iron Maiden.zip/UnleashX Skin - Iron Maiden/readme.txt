Sept 08 2004

Skin Name: Iron Maiden
Skin Version: v1.0
Skin Author: pza (pzamon@gmail.com)

my first UX skin... it's all about Iron Maiden.
supports:
- music
- rss feeds
- icon preview
- screenshot preview
- some useful stats (temp, network, hdd space,...)


how to install
--------------
create a folder "Iron Maiden" in your UX skin directory and then put the Iron Maiden.zip in it.