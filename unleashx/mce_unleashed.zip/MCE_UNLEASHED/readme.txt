Media Center Unleashed v0.1 ( MCE UNLEASHED )
---------------------------------------------

This skin was made for the Unleash Dashboard

The skin is based the XML File from the bizarre skin. I made the adjustments 
to fit the needs for my skin.


**** IMPORTANT NOTICE! ******************************************************
Almost all the graphics are taken from the XBOX MEDIA CENTER Skin. 
So full credit to the original author of that skin!!
*****************************************************************************


This skin was mainly done for myself and a buddy of mine. We both love the
clean look of the Windows XP Media Center. When a new version of UnleashX
is released that supports a new "PopUp SystemInfo Screen" I will update the
skin and release another version.