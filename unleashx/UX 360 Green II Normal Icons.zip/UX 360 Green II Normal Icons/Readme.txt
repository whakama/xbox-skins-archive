Skin: UX360 Green II Normal Icons
Author: the_iLLmatic_one aka MJ Doom

Changes:
-New Layout
-New Media Player
-Profile Window

Ok people its real simple. To make the skin display your unique information follow these steps.

Display Name:
-Unzip skin to a folder.
-in the folder u should see a file call "skin.xml" open the file with a text editor.
-Scroll down until you find this line
<Text Top="70" Left="100" Width="200" Scroll="0" Color="0xFFFFFFFF" Source="Your Name Goes Here" Align="Left"></Text>
-Just type what ever name you want in the parentheses.
-Exit And Save

Display Avatar:
-Delete "avatar.png" from skin folder
-Pick what ever picture you want (must be a .png file) place it the skin folder and rename it "avatar"

Next select all the files in the skin folder and winrar it into a zip file.
FtP to your xbox and enjoy!

If you have any problems pm me on xbox-scene.com forums. the_iLLmatic_one

one.

