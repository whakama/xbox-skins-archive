Thanks Kracker and Jezz_X ^^! 
I use Intro.wmv by kracker and Skin.xml by Jezz.X ^^ !

Folder "MayhemX360" in ---> /C/Sys/Dashboard/Skins/ 

Topic : http://gueux-forum.net/index.php?act=ST&f=48&t=104297&st=0#entry720289

See you space cowboy...