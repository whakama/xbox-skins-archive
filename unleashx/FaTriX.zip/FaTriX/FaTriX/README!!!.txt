hi all,this is a little skin i made for UnleashX,this is my first skin and hope many more to come,just pop the FaTriX folder in ur skins folder on c:\ and happy dayz(if u get the menu with dots(words cut off,like this Gam...or sk... or there just all dots,reboot and all will be fine,its a bug that Unleash is working on)

                           I Live To Give =0)

