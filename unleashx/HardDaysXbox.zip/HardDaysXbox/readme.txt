This is my first ever skin made for anything so don't judge it too harshly. There may be things wrong with it but if there are, fix them yourself!!

I made it using notepad and photoshop. I also used a font included with a skin called stuntmanfx by dragonforce99 so I hope thats ok.