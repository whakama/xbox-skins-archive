- SlipKnot Skin -
-----------------
Name: slipknot-ux
Made for UnleashX.
Used UnleashX v0.36.0620A on a v1.1 XBox in PAL, normal (Width=640*height=576) to make this skin.
Preview video is enabled in the skin.ini
Enjoy!

Made by Darkfall -2004.