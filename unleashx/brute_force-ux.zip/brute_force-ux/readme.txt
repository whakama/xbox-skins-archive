- Brute Force Skin -
--------------------
Name: brute_force-ux
Made for UnleashX.
Used UnleashX v0.36.0620A on a v1.1 XBox in PAL, normal (Width=640*height=576) to make this skin.
Preview video is enabled in the skin.ini and the box on right of screen is used by it.
Enjoy!

Made by Darkfall -2004.