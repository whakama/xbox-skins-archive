
==========================
====JALOVERBOY AKA RTD====
==========================
email: jaloverboy@gmail.com

This skin was inspired by the many functions of my Xbox.

I created this skin using Adobe ImageStyler and Photo Shop.

Blah, blah, blah blah, blah - you get the picture.

You can email me your comments. 


PS: I have fallen in love with creating skins.

Quote: One should put great effort into creating a skin.