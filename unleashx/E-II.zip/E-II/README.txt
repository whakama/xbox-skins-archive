Hi all,this is the fixed version of the Evolution skin i put together
for unleashX,i cant take full cred as i got the background pic frm a MxM
skin called Fusion V3.0 by Habs69Mso,all cred goz to them,i only added the
menu's,preview shots,newsfeed support(and confirmed it workin myself)and screen info etc for it in UnleashX,just pop the E-II folder in the skins folder on c:\ and happy dayz =0)



Fixed menu to show correctly(not like Gam... now shows full names).
Added new background frm Habs69Mso's Fusion V3.0 MxM skin(all cred goz to them for both 
the Evolution(fusion) backgrounds i used)
Adjusted position of the songtime,menu,game preview,screen info etc around a bit frm the 
first version.
Added Fog support(disable or enable  Fog="False" or Fog="True")set as False atm.
Added support for newsfeeds and confirmed workin by my self.
Added suport for news source.
Removed time and date.

hope ya all enjoy and hope to c many more to come


                 I Live To Give =0)
                  

P.S.I notice a couple game names r to long for the box,u can edit the xbe
with XBE_Renamer0.8 frm xbins and rename the xbe so it fits