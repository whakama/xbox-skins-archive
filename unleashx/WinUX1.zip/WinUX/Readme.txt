This skin showcase the video capability of UnleashX. Create a folder under your skin path and place this zip file in there, no need to uncompress.

To let UnleashX auto detect your preview video, name them "preview.xmv" or "preview.wmv". Otherwise, add a Preview attribute pointing to your video file to config.xml or items.xml.

This file uses a video found in "C:\xodash\media\live.xmv". This is the same opening video when you select Live tab from MS Dash, so don't freak out, you are not connecting to Live. The new Live 2.0 enabled dash don't have this file in the same location so it will not work on it (meaning, you won't see the introvideo but the skin will still work). The intro movie can be stopped by pressing the A or Start buttons anytime.