
==========================
====JALOVERBOY AKA RTD====
==========================
email: jaloverboy@gmail.com

she is hot isn't she..


I created this skin using Adobe ImageStyler and Photo Shop.

You can email me your comments. 

Quote: close your mouth now, and go play a game..

