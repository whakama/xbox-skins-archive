
==========================
====JALOVERBOY AKA RTD====
==========================
email: jaloverboy@gmail.com

Sexy sexy sexy sexy sexy, you get my drift?


I created this skin using Adobe ImageStyler and Photo Shop.

You can email me your comments. 


Quote: I just love sexy girls.
