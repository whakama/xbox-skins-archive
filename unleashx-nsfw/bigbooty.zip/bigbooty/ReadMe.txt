
==========================
====JALOVERBOY AKA RTD====
==========================
email: jaloverboy@gmail.com

All guys love a big ass...


I created this skin using Adobe ImageStyler and Photo Shop.

You can email me your comments. 


Quote: Treat ladies with respect..
